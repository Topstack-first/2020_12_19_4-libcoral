Edge TPU runtime APIs
=====================

``edgetpu.h``

.. doxygenfile:: edgetpu.h
