libcoral API
============

.. toctree::
   edgetpu.rst
   inference.rst
   learn.rst
   pipeline.rst